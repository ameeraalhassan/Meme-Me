//
//  UIImagePickerControllerDelegate.swift
//  ImagePicker
//
//  Created by Ameera AlHassan on 5/29/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class TopTextFieldDelegate: NSObject, UITextFieldDelegate{
    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField.text! == "TOP" {
            textField.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
