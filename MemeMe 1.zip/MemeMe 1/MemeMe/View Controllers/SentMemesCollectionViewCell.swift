//
//  SentMemesCollectionViewCell.swift
//  MemeMe
//
//  Created by Ameera AlHassan on 6/15/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class SentMemesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var sentImageView: UIImageView!
    
}
