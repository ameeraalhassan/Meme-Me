//
//  SentMemeDetailsViewController.swift
//  MemeMe
//
//  Created by Ameera AlHassan on 6/16/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

class SentMemeDetailsViewController: UIViewController {
    
    var meme: Meme!
    
    @IBOutlet weak var memedImage: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
        self.memedImage?.image = meme.memedImage
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
}
