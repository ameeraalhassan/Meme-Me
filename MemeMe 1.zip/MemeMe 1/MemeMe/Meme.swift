//
//  Meme.swift
//  MemeMe
//
//  Created by Ameera AlHassan on 6/14/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

// Creating a Meme Object
struct Meme {
    let topText: String
    let bottomText: String
    let originalImage: UIImage
    let memedImage: UIImage
}
